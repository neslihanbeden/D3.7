#!/bin/bash

n1=8
xbRunFolder='/home/bendonitest/XBEACH/runs'
refID='ID001'
currFolder=$(pwd)

# Count the number of directories
nRun=$(ls -lr $xbRunFolder | grep ID* | wc -l)
nRun=$(( nRun-1 ))

n2=$(( nRun%n1 ))
n3=$(( (nRun-n2)/n1 ))

echo 'Multiple XBeach runs'
echo '  We run '$n3' sets, '$n1' elements each'
echo '  Then, we run the last '$n2' runs'
echo '  Start running...'
counter=0
for ff in $xbRunFolder'/ID'*
do
    ID=${ff##*/}
    if [ "$ID" != "$refID" ];
    then
        echo $ID
        counter=$(( counter+1 ))
        n4=$(( counter%n1 ))
        if [ "$n4" == 0 ];
        then
            echo '    Launch run '$ff' and wait...'
            cd $ff
            sbatch -W $ff/slurm_xbeach
            cd $currFolder
        else
            echo '    Launch run '$ff
            cd $ff
            sbatch $ff/slurm_xbeach
            cd $currFolder
        fi
    fi
done

