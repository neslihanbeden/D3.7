#!/bin/bash
#
# Script to update the water level time series to be used as boundary condition
# for the sea level in the hec-ras model
#
inputFile='/home/bendonitest/XBEACH/hecras_input/massa.u01'
cp '/home/bendonitest/XBEACH/hecras_input/massa_orig.u01' $inputFile
dos2unix $inputFile
xbRunFolder='/home/bendonitest/XBEACH/runs'
dtFreq=20 # inverse of lowpass frequency in second
dtOut=5   # delta t in seconds for hecras input
nVar=4    # the location associated to the water-level in the point.dat hecras file
#
# Sets up the MCR environment
#
MCRROOT=/cluster/universal/matlab/opt/matlab_R2012b/MATLAB_Compiler_Runtime/v80/;
MCRJRE=${MCRROOT}/sys/java/jre/glnxa64/jre/lib/amd64;
LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${MCRROOT}/runtime/glnxa64;
LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${MCRROOT}/bin/glnxa64;
LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${MCRROOT}/sys/os/glnxa64;
LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${MCRJRE}/native_threads;
LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${MCRJRE}/server;
LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${MCRJRE};
XAPPLRESDIR=${MCRROOT}/X11/app-defaults;
export LD_LIBRARY_PATH;
export XAPPLRESDIR;

num=0
for ff in ${xbRunFolder}'/ID'*
do
    echo 'Handle '$ff
    inputWlFile=$ff'/point002.dat'
    outputWlFile=$ff'/zs.txt'
    echo '  Apply low-pass filter to water-level time series'
    echo '    Low-pass frequency: '$dtFreq' s'
    echo '    dt output         : '$dtOut' s'
    echo '    Input file        : '$inputWlFile
    echo '    Output file       : '$outputWlFile
    source /home/bendonitest/miniconda3/etc/profile.d/conda.sh
    conda activate pyscripts
    python /home/bendonitest/XBEACH/scripts/filter_xbeach_wl.py $inputWlFile $nVar $dtFreq $dtOut $outputWlFile
    conda deactivate
    echo '  Done'
    inputTxtFile=$outputWlFile
    outputTxtFile=$ff'/zs_hecras.txt'
    echo '  Column vector to HEC-RAS format...'
    echo '    Input ID boundary file : '$inputTxtFile
    echo '    Output ID boundary file: '$outputTxtFile
    /home/bendonitest/XBEACH/scripts/column_to_hecras $inputTxtFile $outputTxtFile
    echo '  Done'

    # Identify the line numbers associated to the ID
    echo '  Start writing on boundary file '$inputFile
    IDn=${ff: -5}
    lineN1=$(sed -n '/'$IDn'/=' $inputFile)
    echo '    '$IDn' is at line '$lineN1
    #echo $IDn
    #echo $lineN1

    # Read the first line (dt of the water level time series)
    dt=$(head -n 1 $outputTxtFile)
    #echo $dt

    # Write the dt value into the inputFile
    text1='Interval='$dt'SEC'
    text1NoWS="$(echo -e "${text1}" | tr -d '[:space:]')"
    lineDt=$(( $lineN1 + 1 ))
    echo '    Write the dt (at line '$lineDt'): '$text1NoWS
    sed -i "${lineDt}s#.*#${text1NoWS}#g" $inputFile

    # Find where the current time series ends
    tempLineEnd=$(sed -n $lineDt,'${/Stage Hydrograph Use Initial Stage/=}' $inputFile)
    previousLineEnd=${tempLineEnd%%[[:space:]]*}
    lineEnd=$(( $previousLineEnd - 1 )) 

    # Remove all the lines associated to the time series
    lineStart=$(( $lineDt + 2 ))
    echo '    lines from '$lineStart' to '$lineEnd' are removed'
    echo '    '$inputFile' saved into tempFile1'    
    sed -e "${lineStart},${lineEnd}d" $inputFile > tempFile1
    # Read line from zs_hecras.txt and write on inputFile
    echo '    start reading from '$outputTxtFile'...'
    echo '    and writing into tempFile1...'
    x=0
    y=$lineStart
    IFS=''  # Empty variable needs to maintain blank space while reading from a file
    while read -r line;
    do  
        x=$(( $x + 1 )) # Skip the first line of the zs_hecras.txt file
        if [ "$x" -gt 1 ];
        then
            #echo $line
            sed ${y}'i\'"$line" tempFile1 > tempFile2
            y=$(( $y + 1 ))
            mv tempFile2 tempFile1
        fi
    done < $outputTxtFile
    echo '    move tempFile1 to '$inputFile
    mv tempFile1 $inputFile
    echo '  Done'
    # Write the number of elements of the time series
    lineNTime=$(( $lineDt + 1 ))
    nTime=$(( ($x - 1)*10 ))
    text2='Stage Hydrograph= '$nTime
    sed -i "${lineNTime}s#.*#${text2}#g" $inputFile
    echo 'Done '$ff
    echo ' '
    num=$(( $num + 1 ))
    echo $num
    if [ "$num" == 34 ];
    then
        exit
    fi
done
unix2dos $inputFile 













