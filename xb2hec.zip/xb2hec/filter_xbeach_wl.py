#!/usr/bin/env python3

import sys

inputFile  = sys.argv[1]
nVar       = sys.argv[2]
dtFreq     = sys.argv[3]
dtOut      = sys.argv[4]
outputFile = sys.argv[5]

def filter_xbeach_wl(inputFile,nVar,dtFreq,dtOut,outputFile):
    # Function to lowpass filter the time evolution of the water level
    # inputFile : file containing water level to process
    # nVar      : number of variable associated to water level (zs)
    # dtFreq    : low-pass frequency [s] (higher frequency are removed)
    # outputFile: file containing filtered water level
    
    # dtFreq controls the output frequency of the signal that is
    # equal to dtOut = (1/3)*(dtFreq)
    
    # Import packages
    import numpy as np
    from scipy import signal
    #import matplotlib.pyplot as plt
   
    nVar = int(nVar)
    dtFreq = float(dtFreq) 
    dtOut = int(dtOut)
    #print("puppa")
    with open(inputFile, 'rb') as fid:
        dataArray = np.fromfile(fid, float).reshape((-1,4)).T
        fid.close()
    
    time = dataArray[0,:]
    #nt = len(time)
    wl = dataArray[nVar-1,:]
    avgWl = np.mean(wl)
    dt = np.mean(np.diff(time)) # delta t [s]
    fs = 1/dt # sampling frequency [Hz]
    lpFreq = 1/dtFreq
    b, a = signal.butter(5, lpFreq, btype='lowpass', fs=fs) 
    wlFilt = signal.filtfilt(b, a, wl-avgWl) + avgWl
    #dtOut = round((1/3)*(dtFreq))
    print('Output frequency is '+str(dtOut)+' s')
    
    #plt.figure(1)
    #plt.plot(time/60,wl,'k')
    #plt.plot(time/60,wlFilt,'r')
    #plt.plot(time[0::dtOut]/60,wlFilt[0::dtOut],'b')
    #plt.xlim(500,510)
    #plt.show

    #nfft = 512;
    #f1, Pxx_den1 = signal.periodogram(wl-avgWl, fs=fs, window='hamm', nfft=nfft, detrend='constant', return_onesided=True, scaling='density', axis=- 1)
    #f2, Pxx_den2 = signal.periodogram(wlFilt-avgWl, fs=fs, window='hamm', nfft=nfft, detrend='constant', return_onesided=True, scaling='density', axis=- 1)
    #f1, Pxx_den1 = signal.welch(wl-avgWl, fs=fs, window='hann', nperseg=nfft, noverlap=nfft/2, detrend='constant', return_onesided=True, scaling='density', axis=- 1)
    #f2, Pxx_den2 = signal.welch(wlFilt-avgWl, fs=fs, window='hann', nperseg=nfft, noverlap=nfft/2, detrend='constant', return_onesided=True, scaling='density', axis=- 1)
    #plt.figure(2)
    #plt.plot(f1, Pxx_den1)
    #plt.plot(f2, Pxx_den2)
    #plt.xlim(0, 0.2)
    #plt.show()
 
    # Check signal energy
    wle = wl - avgWl
    wlfe = wlFilt - avgWl
    e1 = sum(wle**2)/len(wle)
    e2 = sum(wlfe**2)/len(wlfe)
    #e1 = sum(Pxx_den1)
    #e2 = sum(Pxx_den2)
    print('Energy before filtering is '+str(f'{e1:.3f}'))
    print('Energy after filtering is '+str(f'{e2:.3f}'))   
 
    # Write into the output file
    outWl = wlFilt[0::dtOut]
    with open(outputFile, 'w') as f:
        f.write(str(dtOut)+'\n')
        for wLine in outWl:
            wfLine = f'{wLine:.2f}'
            f.write(str(wfLine)+'\n')

filter_xbeach_wl(inputFile,nVar,dtFreq,dtOut,outputFile)
