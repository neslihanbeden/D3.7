#!/bin/bash
#
# Script to copy input file in all transect folder
#

workFolder='/home/bendonitest/XBEACH/runs'
refID='ID001'
#wave='jons_1988_2019_11_28_long.txt'
level='wl_hist_1956_2005_500yr.txt'

refFolder=$workFolder'/'$refID
for ff in $workFolder'/ID'*
do  
    ID=${ff##*/}  
    if [ "$ID" != "$refID" ];
    then
        echo $ID
        echo ' Copy material...'
        # Copy material from the reference folder to the others
        cp $refFolder'/reuse_params.txt' $ff'/params.txt'
        cp $refFolder'/xbeach' $ff'/'.
        cp $refFolder'/slurm_xbeach' $ff'/'.
        cp $refFolder'/qbcflist.bcf' $ff'/'.
        cp $refFolder'/q_series'* $ff'/'.
        cp $refFolder'/ebcflist.bcf' $ff'/'.
        cp $refFolder'/E_series'* $ff'/'.
        #cp $refFolder'/'$wave $ff'/'.
        cp $refFolder'/'$level $ff'/'.
        mkdir -m 755 $ff'/logfiles'
        # Update the slurm_xbeach file
        echo ' Update slurm_xbeach file...'
        txt5='#SBATCH -o /home/bendonitest/XBEACH/runs/'$ID'/logfiles/log_xbeach.%j'
        txt6='#SBATCH -e /home/bendonitest/XBEACH/runs/'$ID'/logfiles/err_xbeach.%j'
        txt40='/home/bendonitest/XBEACH/runs/'$ID'/xbeach'
        sed -i "5s!.*!${txt5}!g" $ff'/slurm_xbeach' 
        sed -i "6s!.*!${txt6}!g" $ff'/slurm_xbeach'
        sed -i "40s!.*!${txt40}!g" $ff'/slurm_xbeach'
        # Update the params.txt file
        echo ' Update params.txt file...'
        # Number of points cross section
        lineNum=$(wc -l < $ff'/s1d_xb.grd')
        nNx=$( sed -n '/nx/=' $ff'/params.txt' )
        nx=$(( $lineNum - 1 ))
        txtNx='nx           = '$nx
        sed -i "${nNx}s/.*/${txtNx}/g" $ff'/params.txt'
        # Extraction points cross section
        extPointsFile=$ff'/ext_points.txt'
        nEP=$( sed -n '/npoints = 2/=' $ff'/params.txt' )
        while read -r line;
        do
            # First number is position offshore
            # Second number is position inshore
            line1=${line%.*}
            txtNEP=$line1'. 0.'
            nEP=$(( $nEP + 1 ))
            sed -i "${nEP}s/.*/${txtNEP}/g" $ff'/params.txt'
        done < $extPointsFile
        echo ' '
    fi
done



